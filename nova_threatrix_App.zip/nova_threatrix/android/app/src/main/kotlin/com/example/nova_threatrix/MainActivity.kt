package com.example.nova_threatrix

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
